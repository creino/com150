﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnPress = New System.Windows.Forms.Button()
        Me.txtHello = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'btnPress
        '
        Me.btnPress.Location = New System.Drawing.Point(111, 12)
        Me.btnPress.Name = "btnPress"
        Me.btnPress.Size = New System.Drawing.Size(75, 23)
        Me.btnPress.TabIndex = 0
        Me.btnPress.Text = "PRESS ME"
        Me.btnPress.UseVisualStyleBackColor = True
        '
        'txtHello
        '
        Me.txtHello.Location = New System.Drawing.Point(101, 100)
        Me.txtHello.Name = "txtHello"
        Me.txtHello.Size = New System.Drawing.Size(100, 20)
        Me.txtHello.TabIndex = 1
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me.txtHello)
        Me.Controls.Add(Me.btnPress)
        Me.Name = "Form1"
        Me.Text = "First Com 150 Form"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnPress As Button
    Friend WithEvents txtHello As TextBox
End Class
