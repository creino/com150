﻿Public Class Form1
    Private Sub btnClick_Click(sender As Object, e As EventArgs) Handles btnClick.Click
        'This was used for simple display of name entered into the text box
        'MessageBox.Show(txtName.Text) 
        'This is used for taking the input from txtName to display in txtOut

        'Write message to end user - "Good Evening...
        'For use with txtOut --->txtOut.Text = "Good Evening Mr. " & txtName.Text & ControlChars.CrLf
        'For use with txtOut --->txtOut.Text = txtOut.Text & "How are you doing today?"

        lstOut.Items.Add("Good Evening Mr. " & txtName.Text)
        lstOut.Items.Add("How are you doing today?")


    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'Clear the prior text
        txtName.Clear()
        lstOut.ClearSelected()


    End Sub
End Class
