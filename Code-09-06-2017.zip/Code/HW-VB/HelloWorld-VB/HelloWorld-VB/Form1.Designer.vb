﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnPress = New System.Windows.Forms.Button()
        Me.lstHello = New System.Windows.Forms.ListView()
        Me.SuspendLayout()
        '
        'btnPress
        '
        Me.btnPress.Location = New System.Drawing.Point(111, 12)
        Me.btnPress.Name = "btnPress"
        Me.btnPress.Size = New System.Drawing.Size(75, 23)
        Me.btnPress.TabIndex = 0
        Me.btnPress.Text = "PRESS ME"
        Me.btnPress.UseVisualStyleBackColor = True
        '
        'lstHello
        '
        Me.lstHello.Alignment = System.Windows.Forms.ListViewAlignment.[Default]
        Me.lstHello.Location = New System.Drawing.Point(47, 52)
        Me.lstHello.Name = "lstHello"
        Me.lstHello.Size = New System.Drawing.Size(184, 97)
        Me.lstHello.TabIndex = 1
        Me.lstHello.UseCompatibleStateImageBehavior = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me.lstHello)
        Me.Controls.Add(Me.btnPress)
        Me.Name = "Form1"
        Me.Text = "First Com 150 Form"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnPress As Button
    Friend WithEvents lstHello As ListView
End Class
