﻿Public Class Form1
    'Default form code     Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    ' End Sub

    'Execise #1
    ' Text Hello World Start --->
    ' Private Sub btnPress_Click(sender As Object, e As EventArgs) Handles btnPress.Click
    '    MessageBox.Show("Hello World!")
    '    MessageBox.Show("Are you sure?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
    ' End Sub <---End
    '
    'Execise #2
    'Text Box Hello World Start --->
    'Private Sub btnPress_Click(sender As Object, e As EventArgs) Handles btnPress.Click
    '   txtHello.Text = "Hello World!"
    '
    'End Sub
    '<---Text Box End

    '
    'Execise #3
    'Text Box Hello World Start ---> !!Requires txtHello Text Box!!
    ' Private Sub btnPress_Click(sender As Object, e As EventArgs) Handles btnPress.Click
    '    txtHello.Text = "Hello World!"
    '
    'End Sub
    '<---Text Box End
    'Execise #4
    'List View Hello World Start ---> !!Requires lstHello List box!!
    Private Sub btnPress_Click(sender As Object, e As EventArgs) Handles btnPress.Click
        lstHello.Items.Add("Hello World!")

    End Sub
    '<---List View End


End Class
